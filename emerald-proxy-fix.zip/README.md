# Emerald Proxy Site

Situs sederhana untuk verifikasi key sebelum mengakses halaman tertentu.

## Deploy ke Vercel
1. Fork atau upload project ini ke GitHub.
2. Buka [Vercel](https://vercel.com) dan import repository.
3. Pilih **Framework Preset** = `Other`.
4. **Build Command** = kosong.
5. **Output Directory** = `.` (titik).
6. Deploy → Selesai.

## Deploy ke GitHub Pages
1. Fork atau push project ini ke GitHub.
2. Buka **Settings → Pages**.
3. Source: `main` branch, folder `/` (root).
4. Save dan tunggu proses selesai.
5. Situs bisa diakses di `https://username.github.io/repo-name`.
